import discord
from discord.ext import commands
import gspread
from oauth2client.service_account import ServiceAccountCredentials

# Define your intents
intents = discord.Intents.default()
intents.messages = True  # Enable the messages intent
intents.message_content = True  # Enable the message content intent

# Discord Bot Setup
bot = commands.Bot(command_prefix='!', intents=intents)

# Google Sheets Setup
scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('/home/user_105131414311165952/axial-reference-275818-fbec39bc736f.json', scope)

client = gspread.authorize(creds)
spreadsheet = client.open('Gang Shed Ledger v2.0')  # Replace with your Google Sheets document name

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name}')

@bot.event
async def on_message(message):
    if message.channel.name == 'shed-numbers':  # Replace with the channel name you want to monitor
        # Log the message to Google Sheets
        log_message_to_sheets(message.author.name, message.content)

    await bot.process_commands(message)

def log_message_to_sheets(author, content):
    sheet = spreadsheet.get_worksheet(0)  # Assuming you want to use the first worksheet

    # Find author's name in row 7
    try:
        cell = sheet.find(author)
    except gspread.exceptions.CellNotFound:
        # If the author's name is not found, add a new row in row 7
        print(f"Author '{author}' not found in row 7. Adding to the next available cell in row 7.")
        row_7_col_A = sheet.col_values(1)[6:]
        next_available_row = 7 + len(row_7_col_A)  # Calculate the next available row
        print(f"Author '{author}' added to row {next_available_row}, column A")
        sheet.update_cell(next_available_row, 1, author)

    # Check if content is numeric
    try:
        numeric_content = int(content)
    except ValueError:
        print(f"Non-numeric content '{content}' for author '{author}'. Adding to row 9.")
        # Find the next empty row in column A, starting from row 9
        row_9_col_A = sheet.col_values(1)[8:]  
        next_empty_row = 9 + len(row_9_col_A)  # Calculate the next empty row
        print(f"Author '{author}' added to row {next_empty_row}, column A")
        sheet.update_cell(next_empty_row, 1, author)
        print(f"Non-numeric content '{content}' added to row {next_empty_row}, column B")
        sheet.update_cell(next_empty_row, 2, content)
        return

    # Content is numeric, update the corresponding cell in the same column under the author's name
    col_index = cell.col
    cell_below_value = sheet.cell(8, col_index).value

    # Handle the case where cell_below_value is None or empty
    if not cell_below_value:
        cell_below_value = '0'

    new_value = int(cell_below_value) + int(content)
    print(f"Updating cell 8, {col_index} with new value: {new_value}")
    
    # Update the cell with the new value
    sheet.update_cell(8, col_index, new_value)

# Run the bot
bot.run('MTE5ODIxODUzODA5MjA3NzA5Ng.GQd9fB.R6LIgPYBexSVvcJEaKsJAOiVyTyBota05oLEDo')  # Replace with your Discord bot token
